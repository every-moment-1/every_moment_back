package com.rookies4.every_moment.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "users",
        indexes = {
                @Index(name = "idx_users_username", columnList = "username"),
                @Index(name = "idx_users_email", columnList = "email")
        },
        uniqueConstraints = {
                @UniqueConstraint(name="uk_users_username", columnNames = "username"),
                @UniqueConstraint(name="uk_users_email", columnNames = "email")
        })
@Getter @Setter @Builder
@NoArgsConstructor @AllArgsConstructor
public class UserEntity {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false, length=40)
    private String username;

    @Column(nullable=false, length=100)
    private String email;

    @Column(name="password_hash", nullable=false, length=255)
    private String passwordHash;

    @Column(nullable=false)
    private Boolean smoking;

    @Column(nullable=false, length=20)
    private String role;

    @Column(nullable=false)
    private Boolean active;

    @Column(name="created_at", insertable=false, updatable=false)
    private LocalDateTime createdAt;


    @Column(name="updated_at", insertable=false, updatable=false)
    private LocalDateTime updatedAt;

    @PrePersist
    public void prePersist() {
        var now = new java.sql.Timestamp(System.currentTimeMillis());
        if (active == null) active = true;
        if (role == null) role = "ROLE_USER";
        if (smoking == null) smoking = false;
    }
}