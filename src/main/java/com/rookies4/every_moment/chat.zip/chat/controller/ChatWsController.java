//package com.rookies4.every_moment.chat.controller;
//
//
//import com.rookies4.every_moment.chat.domain.ChatRoom;
//import com.rookies4.every_moment.chat.dto.ChatMessagePayload;
//import com.rookies4.every_moment.chat.service.ChatService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.messaging.handler.annotation.*;
//import org.springframework.messaging.simp.SimpMessagingTemplate;
//import org.springframework.stereotype.Controller;
//
//import java.security.Principal;
//
//@Controller
//@RequiredArgsConstructor
//public class ChatWsController {
//    private final ChatService chatService;
//    private final SimpMessagingTemplate template;
//
//    // 클라: SEND -> /app/rooms/{roomId}
//    @MessageMapping("/rooms/{roomId}")
//    public void send(@DestinationVariable Long roomId,
//                     ChatMessagePayload payload,
//                     Principal principal) {
//        Long me = Long.valueOf(principal.getName());
//        ChatRoom room = chatService.getRoomIfMember(roomId, me);
//        var saved = chatService.saveMessage(room, me, payload.content());
//        // 구독자에게 브로드캐스트: /topic/rooms/{roomId}
//        template.convertAndSend("/topic/rooms/" + roomId, new Out(saved.getId(), roomId, me, saved.getContent(), saved.getCreatedAt().toString()));
//    }
//
//    public record Out(Long id, Long roomId, Long senderId, String content, String createdAt) {}
//}