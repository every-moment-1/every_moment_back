package com.rookies4.every_moment.chat.dto;

public record CreateRoomRequest(Long opponentUserId) { }