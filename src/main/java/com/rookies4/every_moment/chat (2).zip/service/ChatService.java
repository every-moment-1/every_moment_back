package com.rookies4.every_moment.chat.service;

import com.rookies4.every_moment.chat.domain.ChatRoom;
import com.rookies4.every_moment.chat.domain.ChatMessage;
import com.rookies4.every_moment.chat.repo.ChatRoomRepository;
import com.rookies4.every_moment.chat.repo.ChatMessageRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class ChatService {
    private final ChatRoomRepository roomRepo;
    private final ChatMessageRepository msgRepo;

    public ChatRoom getOrCreateOneOnOneRoom(Long me, Long other) {
        // 정규화: 항상 작은 ID를 userAId에, 큰 ID를 userBId에 저장
        Long a = Math.min(me, other);
        Long b = Math.max(me, other);

        return roomRepo.findByUserAIdAndUserBId(a, b).orElseGet(() -> {
            log.info("Creating new chat room between users {} and {}", a, b);
            ChatRoom room = new ChatRoom();
            room.setUserAId(a);
            room.setUserBId(b);
            room.setCreatedAt(Instant.now());
            return roomRepo.save(room);
        });
    }

    public ChatMessage saveMessage(Long roomId, Long senderId, String content) {
        if (content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("Message content cannot be empty");
        }

        ChatMessage message = new ChatMessage();
        message.setRoomId(roomId);
        message.setSenderId(senderId);
        message.setContent(content.trim());
        message.setCreatedAt(Instant.now());

        log.info("Saving message from user {} in room {}", senderId, roomId);
        return msgRepo.save(message);
    }

    @Transactional(readOnly = true)
    public Page<ChatMessage> getMessages(Long roomId, Pageable pageable) {
        return msgRepo.findByRoomIdOrderByIdDesc(roomId, pageable);
    }

    @Transactional(readOnly = true)
    public List<ChatMessage> getRecentMessages(Long roomId) {
        return msgRepo.findTop50ByRoomIdOrderByIdDesc(roomId);
    }

    public void markReadUpTo(Long roomId, Long userId, Long lastMessageId) {
        msgRepo.markAsRead(roomId, userId, lastMessageId, Instant.now());
        log.info("Marked messages as read in room {} for user {} up to message {}",
                roomId, userId, lastMessageId);
    }

    @Transactional(readOnly = true)
    public boolean isUserInRoom(Long roomId, Long userId) {
        return roomRepo.findByIdAndUserId(roomId, userId).isPresent();
    }

    @Transactional(readOnly = true)
    public ChatRoom getRoomById(Long roomId) {
        return roomRepo.findById(roomId).orElse(null);
    }
}