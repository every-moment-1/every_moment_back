package com.rookies4.every_moment.chat.util;

import com.rookies4.every_moment.chat.domain.ChatMessage;
import com.rookies4.every_moment.chat.domain.ChatMessage;
import com.rookies4.every_moment.chat.dto.ChatMessageResponse;

public class ChatMapper {

    public static ChatMessageResponse toDto(ChatMessage entity) {
        return ChatMessageResponse.builder()
                .id(entity.getId())
                .roomId(entity.getRoomId())
                .senderId(entity.getSenderId())
                .content(entity.getContent())
                .createdAt(entity.getCreatedAt())
                .readAt(entity.getReadAt())
                .build();
    }
}