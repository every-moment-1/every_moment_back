package com.rookies4.every_moment.chat.dto;

public record ChatMessagePayload(Long roomId, String content) { }