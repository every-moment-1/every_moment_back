package com.rookies4.every_moment.chat.config;

import com.rookies4.every_moment.security.jwt.JwtTokenProvider;
import com.rookies4.every_moment.security.jwt.JwtTokenProvider;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Component;
import java.util.ArrayList;

@Component
@RequiredArgsConstructor
@Slf4j
public class StompAuthChannelInterceptor implements ChannelInterceptor {

    private final JwtTokenProvider jwtTokenProvider;

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);

        if (accessor != null) {
            StompCommand command = accessor.getCommand();

            if (StompCommand.CONNECT.equals(command)) {
                String auth = accessor.getFirstNativeHeader("Authorization");

                if (auth != null && auth.startsWith("Bearer ")) {
                    String token = auth.substring(7);

                    try {
                        if (jwtTokenProvider.validate(token)) {
                            Claims claims = jwtTokenProvider.parse(token);
                            Long userId = claims.get("uid", Long.class);

                            if (userId != null) {
                                accessor.setUser(new UsernamePasswordAuthenticationToken(
                                        userId.toString(), null, new ArrayList<>()
                                ));
                                log.info("WebSocket CONNECT - User {} authenticated", userId);
                            } else {
                                throw new AccessDeniedException("Invalid token: missing user ID");
                            }
                        }
                    } catch (Exception e) {
                        log.error("WebSocket authentication failed: {}", e.getMessage());
                        throw new AccessDeniedException("Invalid JWT token");
                    }
                } else {
                    log.warn("WebSocket CONNECT without Authorization header");
                    throw new AccessDeniedException("Missing Authorization header");
                }
            } else if (StompCommand.SUBSCRIBE.equals(command)) {
                if (accessor.getUser() == null) {
                    throw new AccessDeniedException("Not authenticated");
                }
                log.debug("User {} subscribing to {}", accessor.getUser().getName(),
                        accessor.getDestination());
            } else if (StompCommand.SEND.equals(command)) {
                if (accessor.getUser() == null) {
                    throw new AccessDeniedException("Not authenticated");
                }
            }
        }

        return message;
    }
}