package com.rookies4.every_moment.chat.repo;


import com.rookies4.every_moment.chat.domain.ChatRoom;
import com.rookies4.every_moment.chat.domain.ChatRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

@Repository
public interface ChatRoomRepository extends JpaRepository<ChatRoom, Long> {
    Optional<ChatRoom> findByUserAIdAndUserBId(Long userAId, Long userBId);

    @Query("SELECT r FROM ChatRoom r WHERE (r.userAId = :userId OR r.userBId = :userId)")
    List<ChatRoom> findRoomsByUserId(@Param("userId") Long userId);

    @Query("SELECT r FROM ChatRoom r WHERE r.id = :roomId AND (r.userAId = :userId OR r.userBId = :userId)")
    Optional<ChatRoom> findByIdAndUserId(@Param("roomId") Long roomId, @Param("userId") Long userId);
}