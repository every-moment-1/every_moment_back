package com.rookies4.every_moment.chat.repo;


import com.rookies4.every_moment.chat.domain.ChatMessage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.Instant;
import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    Page<ChatMessage> findByRoomIdOrderByIdDesc(Long roomId, Pageable pageable);

    List<ChatMessage> findTop50ByRoomIdOrderByIdDesc(Long roomId);

    @Modifying
    @Query("UPDATE ChatMessage m SET m.readAt = :readAt WHERE m.roomId = :roomId AND m.senderId != :userId AND m.readAt IS NULL AND m.id <= :lastMessageId")
    void markAsRead(@Param("roomId") Long roomId, @Param("userId") Long userId,
                    @Param("lastMessageId") Long lastMessageId, @Param("readAt") Instant readAt);
}