package com.rookies4.every_moment.chat.controller;

import com.rookies4.every_moment.chat.domain.ChatMessage;
import com.rookies4.every_moment.chat.dto.ChatMessageResponse;
import com.rookies4.every_moment.chat.dto.MarkReadRequest;
import com.rookies4.every_moment.chat.dto.SendMessagePayload;
import com.rookies4.every_moment.chat.service.ChatService;
import com.rookies4.every_moment.chat.util.ChatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import java.security.Principal;

@Controller
@RequiredArgsConstructor
@Slf4j
public class ChatStompController {

    private final SimpMessagingTemplate messagingTemplate;
    private final ChatService chatService;

    @MessageMapping("/chat.send.{roomId}")
    public void sendMessage(
            @DestinationVariable Long roomId,
            @Payload SendMessagePayload payload,
            Principal principal) {

        if (principal == null) {
            log.error("Unauthenticated message attempt to room {}", roomId);
            return;
        }

        Long senderId = Long.valueOf(principal.getName());

        // 권한 검증: 발신자가 해당 방의 멤버인지 확인
        if (!chatService.isUserInRoom(roomId, senderId)) {
            log.warn("User {} attempted to send message to room {} without permission",
                    senderId, roomId);
            return;
        }

        // 메시지 검증
        if (payload.getContent() == null || payload.getContent().trim().isEmpty()) {
            log.warn("User {} attempted to send empty message", senderId);
            return;
        }

        // 메시지 길이 제한 (예: 1000자)
        if (payload.getContent().length() > 1000) {
            log.warn("User {} attempted to send message exceeding length limit", senderId);
            return;
        }

        try {
            // DB에 메시지 저장
            ChatMessage saved = chatService.saveMessage(roomId, senderId, payload.getContent());
            ChatMessageResponse response = ChatMapper.toDto(saved);

            // 해당 방을 구독한 모든 사용자에게 브로드캐스트
            messagingTemplate.convertAndSend("/topic/chat.room." + roomId, response);

            log.info("Message sent from user {} to room {}", senderId, roomId);
        } catch (Exception e) {
            log.error("Failed to send message from user {} to room {}: {}",
                    senderId, roomId, e.getMessage());
        }
    }

    @MessageMapping("/chat.typing.{roomId}")
    public void sendTypingIndicator(
            @DestinationVariable Long roomId,
            Principal principal) {

        if (principal == null) return;

        Long userId = Long.valueOf(principal.getName());

        if (!chatService.isUserInRoom(roomId, userId)) {
            return;
        }

        // 타이핑 인디케이터 브로드캐스트
        messagingTemplate.convertAndSend("/topic/chat.typing." + roomId,
                new TypingIndicator(userId, true));
    }

    @MessageMapping("/chat.read.{roomId}")
    public void markAsRead(
            @DestinationVariable Long roomId,
            @Payload MarkReadRequest request,
            Principal principal) {

        if (principal == null) return;

        Long userId = Long.valueOf(principal.getName());

        if (!chatService.isUserInRoom(roomId, userId)) {
            return;
        }

        chatService.markReadUpTo(roomId, userId, request.getLastMessageId());

        // 읽음 표시 알림 브로드캐스트
        messagingTemplate.convertAndSend("/topic/chat.read." + roomId,
                new ReadReceipt(userId, request.getLastMessageId()));
    }

    // Helper DTOs
    private static record TypingIndicator(Long userId, boolean typing) {}
    private static record ReadReceipt(Long userId, Long lastMessageId) {}
}