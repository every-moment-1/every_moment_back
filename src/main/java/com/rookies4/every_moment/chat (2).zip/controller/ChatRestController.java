package com.rookies4.every_moment.chat.controller;

import com.rookies4.every_moment.chat.domain.ChatRoom;
import com.rookies4.every_moment.chat.dto.*;
import com.rookies4.every_moment.chat.service.ChatService;
import com.rookies4.every_moment.chat.util.ChatMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.http.ResponseEntity.*;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
@Slf4j
public class ChatRestController {

    private final ChatService chatService;

    @PostMapping("/rooms")
    public ResponseEntity<CreateRoomResponse> createOrGetRoom(
            @AuthenticationPrincipal(expression = "name") String meStr,
            @RequestBody CreateRoomRequest request) {

        Long me = Long.valueOf(meStr);
        Long other = request.getOtherUserId();

        if (me.equals(other)) {
            return badRequest().build();
        }

        log.info("Creating/getting room between users {} and {}", me, other);
        ChatRoom room = chatService.getOrCreateOneOnOneRoom(me, other);

        return ok(new CreateRoomResponse(room.getId()));
    }

    @GetMapping("/rooms/{roomId}/messages")
    public ResponseEntity<Page<ChatMessageResponse>> getMessages(
            @PathVariable Long roomId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @AuthenticationPrincipal(expression = "name") String userStr) {

        Long userId = Long.valueOf(userStr);

        // 권한 검증: 사용자가 해당 방의 멤버인지 확인
        if (!chatService.isUserInRoom(roomId, userId)) {
            log.warn("User {} attempted to access room {} without permission", userId, roomId);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        Page<ChatMessageResponse> messages = chatService
                .getMessages(roomId, PageRequest.of(page, size))
                .map(ChatMapper::toDto);

        return ok(messages);
    }

    @GetMapping("/rooms/{roomId}/recent")
    public ResponseEntity<List<ChatMessageResponse>> getRecentMessages(
            @PathVariable Long roomId,
            @AuthenticationPrincipal(expression = "name") String userStr) {

        Long userId = Long.valueOf(userStr);

        if (!chatService.isUserInRoom(roomId, userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        List<ChatMessageResponse> messages = chatService
                .getRecentMessages(roomId)
                .stream()
                .map(ChatMapper::toDto)
                .collect(Collectors.toList());

        return ok(messages);
    }

    @PostMapping("/rooms/{roomId}/read")
    public ResponseEntity<Void> markAsRead(
            @PathVariable Long roomId,
            @RequestBody MarkReadRequest request,
            @AuthenticationPrincipal(expression = "name") String userStr) {

        Long userId = Long.valueOf(userStr);

        if (!chatService.isUserInRoom(roomId, userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        chatService.markReadUpTo(roomId, userId, request.getLastMessageId());
        return ok().build();
    }
}